﻿namespace ApiRestVisualContact.enums
{
    public enum Estados
    {
        Disponible,
        EnLlamada,
        Ocupado,
        Inactivo
    }
}
